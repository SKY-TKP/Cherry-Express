<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>หน้าสารบัญ</title>
</head>
<body>

<h1>หน้าสารบัญ</h1>

<ul>
  <li><a href="index.php">หน้าแรก</a></li>
  <li><a href="product_list.php">รายการสินค้า</a></li>
  <li><a href="admin/add_product.php">เพิ่มสินค้า</a></li>
  <li><a href="admin/remove_product.php">เอาสินค้าออก</a></li>
</ul>

</body>
</html>