<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>รายการสินค้า</title>
</head>
<body>

<h1>รายการสินค้า</h1>

<?php
// ดึงข้อมูลประเภทซูชิ
$stmt = $conn->query("SELECT * FROM SushiTypes");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
  $typeId = $row['TypeID'];
  $typeName = $row['TypeName'];

  // นับจำนวนสินค้าและหาราคาต่ำสุด-สูงสุด
  $stmt2 = $conn->prepare("SELECT COUNT(*) AS count, MIN(Price) AS min_price, MAX(Price) AS max_price FROM Products WHERE TypeID = :typeID");
  $stmt2->bindParam(':typeID', $typeId);
  $stmt2->execute();
  $result2 = $stmt2->fetch(PDO::FETCH_ASSOC);

  echo "<p><a href='product_list.php?type=$typeId'>$typeName</a> ({$result2['count']}) ราคา: {$result2['min_price']} - {$result2['max_price']}</p>";
}
?>

<?php
// แสดงรายการสินค้าตามประเภท
if (isset($_GET['type'])) {
  $typeId = $_GET['type'];

  // เรียงลำดับข้อมูล
  $orderBy = isset($_GET['order']) ? $_GET['order'] : 'ASC';

  $stmt = $conn->prepare("SELECT * FROM Products WHERE TypeID = :typeID ORDER BY Price $orderBy");
  $stmt->bindParam(':typeID', $typeId);
  $stmt->execute();

  echo "<h2>สินค้าประเภท: " . $typeName . "</h2>";
  echo "<p><a href='product_list.php?type=$typeId&order=" . ($orderBy == 'ASC' ? 'DESC' : 'ASC') . "'>เรียงลำดับราคา " . ($orderBy == 'ASC' ? 'สูง-ต่ำ' : 'ต่ำ-สูง') . "</a></p>";

  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<p>{$row['ProductName']} - {$row['Price']}</p>";
  }
}
?>

</body>
</html>