<?php include '../includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>เพิ่มสินค้า</title>
</head>
<body>

<h1>เพิ่มสินค้า</h1>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $productName = $_POST['productName'];
  $price = $_POST['price'];
  $typeId = $_POST['typeId'];

  // ตรวจสอบชื่อซ้ำ
  $stmt = $conn->prepare("SELECT * FROM Products WHERE ProductName = :productName");
  $stmt->bindParam(':productName', $productName);
  $stmt->execute();

  if ($stmt->rowCount() > 0) {
    echo "<p>ชื่อสินค้าซ้ำ</p>";
  } else {
    // เพิ่มสินค้า
    $stmt = $conn->prepare("INSERT INTO Products (ProductName, Price, TypeID) VALUES (:productName, :price, :typeId)");
    $stmt->bindParam(':productName', $productName);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':typeId', $typeId);

    if ($stmt->execute()) {
      echo "<p>เพิ่มสินค้าสำเร็จ</p>";
    } else {
      echo "<p>เกิดข้อผิดพลาด</p>";
    }
  }
}
?>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <label for="typeId">ประเภท:</label>
  <select name="typeId" id="typeId">
    <?php
    $stmt = $conn->query("SELECT * FROM SushiTypes");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<option value='{$row['TypeID']}'>{$row['TypeName']}</option>";
    }
    ?>
  </select><br><br>

  <label for="productName">ชื่อสินค้า:</label>
  <input type="text" name="productName" id="productName" required><br><br>

  <label for="price">ราคา:</label>
  <input type="number" name="price" id="price" required><br><br>

  <input type="submit" value="เพิ่มสินค้า">
</form>

</body>
</html>