<?php include '../includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>เอาสินค้าออก</title>
</head>
<body>

<h1>เอาสินค้าออก</h1>

<?php
if (isset($_GET['delete'])) {
  $productId = $_GET['delete'];

  // ลบสินค้า
  $stmt = $conn->prepare("DELETE FROM Products WHERE ProductID = :productId");
  $stmt->bindParam(':productId', $productId);

  if ($stmt->execute()) {
    echo "<p>ลบสินค้าสำเร็จ</p>";
  } else {
    echo "<p>เกิดข้อผิดพลาด</p>";
  }
}
?>

<table>
  <thead>
    <tr>
      <th>ชื่อสินค้า</th>
      <th>ราคา</th>
      <th>ประเภท</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php
    $stmt = $conn->query("SELECT p.*, t.TypeName FROM Products p JOIN SushiTypes t ON p.TypeID = t.TypeID");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<tr>";
      echo "<td>{$row['ProductName']}</td>";
      echo "<td>{$row['Price']}</td>";
      echo "<td>{$row['TypeName']}</td>";
      echo "<td><a href='?delete={$row['ProductID']}'>ลบ</a></td>";
      echo "</tr>";
    }
    ?>
  </tbody>
</table>

</body>
</html>