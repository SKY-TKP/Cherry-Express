<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>เพิ่มผู้สนใจเที่ยว</title>
</head>
<body>

<h1>เพิ่มผู้สนใจเที่ยว</h1>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['name'];
  $phoneNumber = $_POST['phoneNumber'];
  $email = $_POST['email'];
  $groupSize = $_POST['groupSize'];
  $budget = $_POST['budget'];

  // Add traveler to the database
  try {
    $stmt = $conn->prepare("INSERT INTO Travelers (Name, PhoneNumber, Email, GroupSize, Budget) 
                            VALUES (:name, :phoneNumber, :email, :groupSize, :budget)");
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':phoneNumber', $phoneNumber);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':groupSize', $groupSize);
    $stmt->bindParam(':budget', $budget);
    $stmt->execute();

    // Get the last inserted TravelerID
    $travelerID = $conn->lastInsertId();

    // Add interests (assuming you have a checkbox list of destinations in your form)
    if (isset($_POST['destinations'])) {
      $destinations = $_POST['destinations'];
      foreach ($destinations as $destinationID) {
        $stmt = $conn->prepare("INSERT INTO Interests (TravelerID, DestinationID) 
                                VALUES (:travelerID, :destinationID)");
        $stmt->bindParam(':travelerID', $travelerID);
        $stmt->bindParam(':destinationID', $destinationID);
        $stmt->execute();
      }
    }

    echo "<p>เพิ่มผู้สนใจเที่ยวสำเร็จ</p>";
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}
?>

<form method="post">
  <label for="name">ชื่อ:</label>
  <input type="text" name="name" id="name" required><br><br>

  <label for="phoneNumber">เบอร์โทรศัพท์:</label>
  <input type="text" name="phoneNumber" id="phoneNumber"><br><br>

  <label for="email">Email:</label>
  <input type="email" name="email" id="email" required><br><br>

  <label for="groupSize">จำนวนคน:</label>
  <input type="number" name="groupSize" id="groupSize"><br><br>

  <label for="budget">งบประมาณ:</label>
  <input type="number" name="budget" id="budget"><br><br>

  <label>เมืองที่สนใจ:</label><br>
  <?php
  $stmt = $conn->query("SELECT * FROM Destinations");
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<input type='checkbox' name='destinations[]' value='{$row['DestinationID']}'> {$row['CityName']}<br>";
  }
  ?>
  <br>

  <input type="submit" value="เพิ่มผู้สนใจเที่ยว">
</form>

</body>
</html>