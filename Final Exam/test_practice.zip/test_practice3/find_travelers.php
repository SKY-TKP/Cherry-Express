<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>ผู้สนใจขายทัวร์</title>
</head>
<body>

<h1>ผู้สนใจขายทัวร์</h1>

<form method="get" action="find_travelers.php">
  <label for="city">เลือกเมือง:</label>
  <select name="city" id="city">
    <?php
    $stmt = $conn->query("SELECT * FROM Destinations");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      $selected = (isset($_GET['city']) && $_GET['city'] == $row['DestinationID']) ? 'selected' : '';
      echo "<option value='{$row['DestinationID']}' $selected>{$row['CityName']}</option>";
    }
    ?>
  </select>
  <br><br>

  <label for="order">เรียงลำดับตาม:</label>
  <select name="order" id="order">
    <option value="GroupSize" <?php if (isset($_GET['order']) && $_GET['order'] == 'GroupSize') echo 'selected'; ?>>จำนวนคน</option>
    <option value="Budget" <?php if (isset($_GET['order']) && $_GET['order'] == 'Budget') echo 'selected'; ?>>งบประมาณ</option>
  </select>
  <input type="submit" value="ค้นหา">
</form>

<?php
if (isset($_GET['city'])) {
  $cityID = $_GET['city'];
  $orderBy = isset($_GET['order']) ? $_GET['order'] : 'GroupSize';

  try {
    $stmt = $conn->prepare("SELECT t.Name, t.GroupSize, t.Budget 
                            FROM Travelers t
                            INNER JOIN Interests i ON t.TravelerID = i.TravelerID
                            WHERE i.DestinationID = :cityID
                            ORDER BY $orderBy DESC"); // Changed to DESC for high to low ordering
    $stmt->bindParam(':cityID', $cityID);
    $stmt->execute();

    echo "<h2>ผู้สนใจเที่ยวเมือง: " . $_GET['city'] . "</h2>";
    echo "<table>";
    echo "<thead><tr><th>ชื่อ</th><th>จำนวนคน</th><th>งบประมาณ</th></tr></thead>";
    echo "<tbody>";
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<tr>";
      echo "<td>{$row['Name']}</td>";
      echo "<td>{$row['GroupSize']}</td>";
      echo "<td>{$row['Budget']}</td>";
      echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";

    // Link to sell_tour.php with city ID
    echo "<br><a href='sell_tour.php?city=$cityID'>ขายทัวร์</a>";

  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}
?>

</body>
</html>