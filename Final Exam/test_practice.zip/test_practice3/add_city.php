<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>สร้างเมืองเป้าหมาย</title>
</head>
<body>

<h1>สร้างเมืองเป้าหมาย</h1>

<?php
// Add City
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])) {
  $cityName = $_POST['cityName'];
  $slogan = $_POST['slogan'];
  $recommendedDays = $_POST['recommendedDays'];

  try {
    $stmt = $conn->prepare("INSERT INTO Destinations (CityName, Slogan, RecommendedDays) 
                            VALUES (:cityName, :slogan, :recommendedDays)");
    $stmt->bindParam(':cityName', $cityName);
    $stmt->bindParam(':slogan', $slogan);
    $stmt->bindParam(':recommendedDays', $recommendedDays);
    $stmt->execute();
    echo "<p>เพิ่มเมืองสำเร็จ</p>";
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}

// Edit City
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit'])) {
  $destinationID = $_POST['destinationID'];
  $cityName = $_POST['cityName'];
  $slogan = $_POST['slogan'];
  $recommendedDays = $_POST['recommendedDays'];

  try {
    $stmt = $conn->prepare("UPDATE Destinations SET 
                            CityName = :cityName, 
                            Slogan = :slogan, 
                            RecommendedDays = :recommendedDays 
                            WHERE DestinationID = :destinationID");
    $stmt->bindParam(':destinationID', $destinationID);
    $stmt->bindParam(':cityName', $cityName);
    $stmt->bindParam(':slogan', $slogan);
    $stmt->bindParam(':recommendedDays', $recommendedDays);
    $stmt->execute();
    echo "<p>แก้ไขเมืองสำเร็จ</p>";
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}

// Delete City 
if (isset($_GET['delete'])) {
  $destinationID = $_GET['delete'];

  try {
    // Check if any travelers are interested in this city
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Interests WHERE DestinationID = :destinationID");
    $stmt->bindParam(':destinationID', $destinationID);
    $stmt->execute();
    $interestCount = $stmt->fetchColumn();

    if ($interestCount > 0) {
      echo "<p>ไม่สามารถลบเมืองนี้ได้ เนื่องจากมีผู้สนใจแล้ว</p>";
    } else {
      $stmt = $conn->prepare("DELETE FROM Destinations WHERE DestinationID = :destinationID");
      $stmt->bindParam(':destinationID', $destinationID);
      $stmt->execute();
      echo "<p>ลบเมืองสำเร็จ</p>";
    }
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}
?>

<h2>รายการเมืองเป้าหมาย</h2>

<table>
  <thead>
    <tr>
      <th>ชื่อเมือง</th>
      <th>คำโฆษณา</th>
      <th>จำนวนวันที่ควรเที่ยว</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php
    $stmt = $conn->query("SELECT * FROM Destinations");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<tr>";
      echo "<td>{$row['CityName']}</td>";
      echo "<td>{$row['Slogan']}</td>";
      echo "<td>{$row['RecommendedDays']}</td>";
      echo "<td><a href='?edit={$row['DestinationID']}'>แก้ไข</a></td>";
      echo "<td><a href='?delete={$row['DestinationID']}'>ลบ</a></td>";
      echo "</tr>";
    }
    ?>
  </tbody>
</table>

<h2>เพิ่มเมือง</h2>
<form method="post">
  <label for="cityName">ชื่อเมือง:</label>
  <input type="text" name="cityName" id="cityName" required><br><br>

  <label for="slogan">คำโฆษณา:</label>
  <input type="text" name="slogan" id="slogan"><br><br>

  <label for="recommendedDays">จำนวนวันที่ควรเที่ยว:</label>
  <input type="number" name="recommendedDays" id="recommendedDays"><br><br>

  <input type="submit" name="add" value="เพิ่มเมือง">
</form>

<?php
if (isset($_GET['edit'])) {
  $destinationID = $_GET['edit'];
  $stmt = $conn->prepare("SELECT * FROM Destinations WHERE DestinationID = :destinationID");
  $stmt->bindParam(':destinationID', $destinationID);
  $stmt->execute();
  $city = $stmt->fetch(PDO::FETCH_ASSOC);
  ?>
  <h2>แก้ไขเมือง</h2>
  <form method="post">
    <input type="hidden" name="destinationID" value="<?php echo $city['DestinationID']; ?>">

    <label for="cityName">ชื่อเมือง:</label>
    <input type="text" name="cityName" id="cityName" value="<?php echo $city['CityName']; ?>" required><br><br>

    <label for="slogan">คำโฆษณา:</label>
    <input type="text" name="slogan" id="slogan" value="<?php echo $city['Slogan']; ?>"><br><br>

    <label for="recommendedDays">จำนวนวันที่ควรเที่ยว:</label>
    <input type="number" name="recommendedDays" id="recommendedDays" value="<?php echo $city['RecommendedDays']; ?>"><br><br>

    <input type="submit" name="edit" value="บันทึก">
  </form>
  <?php
}
?>

</body>
</html>