<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>Main Page</title>
</head>
<body>

<h1>Main Page</h1>

<ul>
  <li><a href="main.php">หน้าแรก</a></li>
  <li><a href="add_city.php">สร้างเมืองเป้าหมาย</a></li>
  <li><a href="add_traveler.php">เพิ่มผู้สนใจเที่ยว</a></li>
  <li><a href="find_travelers.php">ผู้สนใจขายทัวร์</a></li>
  <li><a href="sell_tour.php">ขายทัวร์</a></li>
  <li><a href="view_tours.php">ดูทัวร์</a></li>
</ul>

</body>
</html>