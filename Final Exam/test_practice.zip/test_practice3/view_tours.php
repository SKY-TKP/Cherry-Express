<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>ดูทัวร์</title>
</head>
<body>

<h1>ดูทัวร์</h1>

<form method="get" action="view_tours.php">
  <label for="email">กรอก Email:</label>
  <input type="email" name="email" id="email" required>
  <input type="submit" value="ดูทัวร์">
</form>

<?php
if (isset($_GET['email'])) {
  $email = $_GET['email'];

  try {
    // Fetch tour packages offered for the given email
    $stmt = $conn->prepare("SELECT tp.CompanyName, tp.Price, tp.Duration, d.CityName
                            FROM TourProviders tp
                            INNER JOIN Destinations d ON tp.DestinationID = d.DestinationID
                            INNER JOIN Interests i ON tp.DestinationID = i.DestinationID
                            INNER JOIN Travelers t ON i.TravelerID = t.TravelerID
                            WHERE t.Email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
      echo "<h2>ทัวร์สำหรับคุณ: $email</h2>";
      echo "<table>";
      echo "<thead><tr><th>ชื่อบริษัท</th><th>ราคา</th><th>จำนวนวัน</th><th>เมือง</th></tr></thead>";
      echo "<tbody>";
      while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td>{$row['CompanyName']}</td>";
        echo "<td>{$row['Price']}</td>";
        echo "<td>{$row['Duration']}</td>";
        echo "<td>{$row['CityName']}</td>";
        echo "</tr>";
      }
      echo "</tbody>";
      echo "</table>";
    } else {
      echo "<p>ไม่พบข้อมูลทัวร์สำหรับ Email นี้</p>";
    }
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}
?>

</body>
</html>