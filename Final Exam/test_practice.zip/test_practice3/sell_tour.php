<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>ขายทัวร์</title>
</head>
<body>

<h1>ขายทัวร์</h1>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $companyName = $_POST['companyName'];
  $price = $_POST['price'];
  $duration = $_POST['duration'];
  $cityID = $_POST['cityID']; // Get the city ID

  try {
    $stmt = $conn->prepare("INSERT INTO TourProviders (CompanyName, Price, Duration, DestinationID) 
                            VALUES (:companyName, :price, :duration, :cityID)");
    $stmt->bindParam(':companyName', $companyName);
    $stmt->bindParam(':price', $price);
    $stmt->bindParam(':duration', $duration);
    $stmt->bindParam(':cityID', $cityID); 
    $stmt->execute();
    echo "<p>เพิ่มทัวร์สำเร็จ</p>";
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}
?>

<?php
// Get the city ID from the URL parameter
if (isset($_GET['city'])) {
  $cityID = $_GET['city']; 

  // Fetch the city name for display
  $stmt = $conn->prepare("SELECT CityName FROM Destinations WHERE DestinationID = :cityID");
  $stmt->bindParam(':cityID', $cityID);
  $stmt->execute();
  $city = $stmt->fetch(PDO::FETCH_ASSOC);
  $cityName = $city['CityName'];

  ?>
  <h2>ขายทัวร์สำหรับเมือง: <?php echo $cityName; ?></h2>
  <form method="post">
    <input type="hidden" name="cityID" value="<?php echo $cityID; ?>"> <label for="companyName">ชื่อบริษัท:</label>
    <input type="text" name="companyName" id="companyName" required><br><br>

    <label for="price">ราคา:</label>
    <input type="number" name="price" id="price" required><br><br>

    <label for="duration">จำนวนวัน:</label>
    <input type="number" name="duration" id="duration" required><br><br>

    <input type="submit" value="เพิ่มทัวร์">
  </form>
  <?php
} else {
  echo "<p>กรุณาเลือกเมืองจากหน้า 'ผู้สนใจขายทัวร์'</p>";
}
?>

</body>
</html>