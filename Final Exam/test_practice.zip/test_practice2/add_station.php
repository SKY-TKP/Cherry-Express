<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>สร้างสถานีรถไฟฟ้า</title>
</head>
<body>

<h1>สร้างสถานีรถไฟฟ้า</h1>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add'])) {
  $stationName = $_POST['stationName'];
  $phoneNumber = $_POST['phoneNumber'];
  $avgUsers = $_POST['avgUsers'];

  $stmt = $conn->prepare("INSERT INTO Stations (StationName, PhoneNumber, AvgUsers) 
                          VALUES (:stationName, :phoneNumber, :avgUsers)");
  $stmt->bindParam(':stationName', $stationName);
  $stmt->bindParam(':phoneNumber', $phoneNumber);
  $stmt->bindParam(':avgUsers', $avgUsers);

  try {
    $stmt->execute();
    echo "<p>เพิ่มสถานีสำเร็จ</p>";
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
} 
?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit'])) {
  $stationID = $_POST['stationID'];
  $stationName = $_POST['stationName'];
  $phoneNumber = $_POST['phoneNumber'];
  $avgUsers = $_POST['avgUsers'];

  $stmt = $conn->prepare("UPDATE Stations SET 
                          StationName = :stationName, 
                          PhoneNumber = :phoneNumber, 
                          AvgUsers = :avgUsers 
                          WHERE StationID = :stationID");
  $stmt->bindParam(':stationID', $stationID);
  $stmt->bindParam(':stationName', $stationName);
  $stmt->bindParam(':phoneNumber', $phoneNumber);
  $stmt->bindParam(':avgUsers', $avgUsers);

  try {
    $stmt->execute();
    echo "<p>แก้ไขสถานีสำเร็จ</p>";
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}
?>

<?php
if (isset($_GET['delete'])) {
  $stationID = $_GET['delete'];

  $stmt = $conn->prepare("DELETE FROM Stations WHERE StationID = :stationID");
  $stmt->bindParam(':stationID', $stationID);

  try {
    $stmt->execute();
    echo "<p>ลบสถานีสำเร็จ</p>";
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}
?>

<h2>รายการสถานีรถไฟฟ้า</h2>

<form method="get">
  <label for="order">เรียงลำดับ:</label>
  <select name="order" id="order">
    <option value="StationName">ชื่อสถานี</option>
    <option value="AvgUsers">จำนวนผู้ใช้งานเฉลี่ย</option>
  </select>
  <input type="submit" value="เรียง">
</form>

<table>
  <thead>
    <tr>
      <th>ชื่อสถานี</th>
      <th>เบอร์โทร</th>
      <th>จำนวนผู้ใช้งานเฉลี่ย</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php
    $orderBy = isset($_GET['order']) ? $_GET['order'] : 'StationName';
    $stmt = $conn->query("SELECT * FROM Stations ORDER BY $orderBy");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<tr>";
      echo "<td>{$row['StationName']}</td>";
      echo "<td>{$row['PhoneNumber']}</td>";
      echo "<td>{$row['AvgUsers']}</td>";
      echo "<td><a href='?edit={$row['StationID']}'>แก้ไข</a></td>";
      echo "<td><a href='?delete={$row['StationID']}'>ลบ</a></td>";
      echo "</tr>";
    }
    ?>
  </tbody>
</table>

<h2>เพิ่มสถานี</h2>
<form method="post">
  <label for="stationName">ชื่อสถานี:</label>
  <input type="text" name="stationName" id="stationName" required><br><br>

  <label for="phoneNumber">เบอร์โทร:</label>
  <input type="text" name="phoneNumber" id="phoneNumber"><br><br>

  <label for="avgUsers">จำนวนผู้ใช้งานเฉลี่ย:</label>
  <input type="number" name="avgUsers" id="avgUsers"><br><br>

  <input type="submit" name="add" value="เพิ่มสถานี">
</form>

<?php
if (isset($_GET['edit'])) {
  $stationID = $_GET['edit'];
  $stmt = $conn->prepare("SELECT * FROM Stations WHERE StationID = :stationID");
  $stmt->bindParam(':stationID', $stationID);
  $stmt->execute();
  $station = $stmt->fetch(PDO::FETCH_ASSOC);
  ?>
  <h2>แก้ไขสถานี</h2>
  <form method="post">
    <input type="hidden" name="stationID" value="<?php echo $station['StationID']; ?>">

    <label for="stationName">ชื่อสถานี:</label>
    <input type="text" name="stationName" id="stationName" value="<?php echo $station['StationName']; ?>" required><br><br>

    <label for="phoneNumber">เบอร์โทร:</label>
    <input type="text" name="phoneNumber" id="phoneNumber" value="<?php echo $station['PhoneNumber']; ?>"><br><br>

    <label for="avgUsers">จำนวนผู้ใช้งานเฉลี่ย:</label>
    <input type="number" name="avgUsers" id="avgUsers" value="<?php echo $station['AvgUsers']; ?>"><br><br>

    <input type="submit" name="edit" value="บันทึก">
  </form>
  <?php
}
?>

<br>
<a href="buy_ad.php">ซื้อป้ายโฆษณา</a>

</body>
</html>