<!DOCTYPE html>
<html>
<head>
  <title>Main Page</title>
</head>
<body>

<h1>Main Page</h1>

<ul>
  <li><a href="index.php">หน้าแรก</a></li>
  <li><a href="add_station.php">สร้างสถานีรถไฟฟ้า</a></li>
  <li><a href="add_agency.php">เพิ่มชื่อเอเจนซี</a></li>
  <li><a href="buy_ad.php">ซื้อป้ายโฆษณา</a></li>
  <li><a href="admin/">หน้าผู้บริหาร</a></li>
</ul>

</body>
</html>