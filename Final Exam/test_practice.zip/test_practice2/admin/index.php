<?php include '../includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>หน้าผู้บริหาร</title>
</head>
<body>

<h1>หน้าผู้บริหาร</h1>

<h2>รายชื่อโฆษณา</h2>
<?php
$stmt = $conn->query("SELECT s.StationName, a.AdName 
                      FROM Advertisements a
                      JOIN Stations s ON a.StationID = s.StationID
                      ORDER BY s.StationName");
$currentStation = null;
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
  if ($row['StationName'] != $currentStation) {
    if ($currentStation != null) {
      echo "</ul>";
    }
    $currentStation = $row['StationName'];
    echo "<h3>$currentStation</h3>";
    echo "<ul>";
  }
  echo "<li>{$row['AdName']}</li>";
}
if ($currentStation != null) {
  echo "</ul>";
}
?>

<h2>รายชื่อเอเจนซี</h2>
<table>
  <thead>
    <tr>
      <th>ชื่อเอเจนซี</th>
      <th>จำนวนวันที่ใช้</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <?php
    // (สมมติว่ายังไม่มีข้อมูลจำนวนวันที่ใช้)
    $stmt = $conn->query("SELECT * FROM Agencies");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<tr>";
      echo "<td>{$row['AgencyName']}</td>";
      echo "<td>(จำนวนวันที่ใช้)</td>"; //  ต้องเพิ่ม logic คำนวณจำนวนวันที่ใช้
      echo "<td><a href='?delete={$row['AgencyID']}'>ลบโฆษณา</a></td>";
      echo "</tr>";
    }
    ?>
  </tbody>
</table>

<?php
if (isset($_GET['delete'])) {
  $agencyID = $_GET['delete'];

  // ลบโฆษณาของเอเจนซี
  $stmt = $conn->prepare("DELETE FROM Advertisements WHERE AgencyID = :agencyID");
  $stmt->bindParam(':agencyID', $agencyID);

  try {
    $stmt->execute();
    echo "<p>ลบโฆษณาของเอเจนซีสำเร็จ</p>";
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}
?>

</body>
</html>