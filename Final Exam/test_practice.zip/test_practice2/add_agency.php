<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>เพิ่มชื่อเอเจนซี</title>
</head>
<body>

<h1>เพิ่มชื่อเอเจนซี</h1>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $agencyName = $_POST['agencyName'];
  $contactNumber = $_POST['contactNumber'];

  $stmt = $conn->prepare("INSERT INTO Agencies (AgencyName, ContactNumber) 
                          VALUES (:agencyName, :contactNumber)");
  $stmt->bindParam(':agencyName', $agencyName);
  $stmt->bindParam(':contactNumber', $contactNumber);

  try {
    $stmt->execute();
    echo "<p>เพิ่มเอเจนซีสำเร็จ</p>";
  } catch(PDOException $e) {
    echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
  }
}
?>

<form method="post">
  <label for="agencyName">ชื่อเอเจนซี:</label>
  <input type="text" name="agencyName" id="agencyName" required><br><br>

  <label for="contactNumber">เบอร์ติดต่อ:</label>
  <input type="text" name="contactNumber" id="contactNumber"><br><br>

  <input type="submit" value="เพิ่มเอเจนซี">
</form>

</body>
</html>