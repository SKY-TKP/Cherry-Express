<?php include 'includes/database.php'; ?>

<!DOCTYPE html>
<html>
<head>
  <title>ซื้อป้ายโฆษณา</title>
</head>
<body>

<h1>ซื้อป้ายโฆษณา</h1>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $adName = $_POST['adName'];
  $quantity = $_POST['quantity'];
  $stationID = $_POST['stationID'];
  $agencyID = $_POST['agencyID'];

  // ตรวจสอบจำนวนโฆษณา
  $stmt = $conn->prepare("SELECT COUNT(*) FROM Advertisements WHERE StationID = :stationID");
  $stmt->bindParam(':stationID', $stationID);
  $stmt->execute();
  $adCount = $stmt->fetchColumn();

  if ($adCount >= 10) {
    echo "<p>สถานีนี้มีโฆษณาเกิน 10 รายการแล้ว</p>";
  } else {
    // เพิ่มโฆษณา
    $stmt = $conn->prepare("INSERT INTO Advertisements (AdName, Quantity, StationID, AgencyID) 
                            VALUES (:adName, :quantity, :stationID, :agencyID)");
    $stmt->bindParam(':adName', $adName);
    $stmt->bindParam(':quantity', $quantity);
    $stmt->bindParam(':stationID', $stationID);
    $stmt->bindParam(':agencyID', $agencyID);

    try {
      $stmt->execute();
      echo "<p>ซื้อป้ายโฆษณาสำเร็จ</p>";
    } catch(PDOException $e) {
      echo "<p>เกิดข้อผิดพลาด: " . $e->getMessage() . "</p>";
    }
  }
}
?>

<form method="post">
  <label for="stationID">สถานี:</label>
  <select name="stationID" id="stationID">
    <?php
    $stmt = $conn->query("SELECT * FROM Stations");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<option value='{$row['StationID']}'>{$row['StationName']}</option>";
    }
    ?>
  </select><br><br>

  <label for="adName">ชื่อโฆษณา:</label>
  <input type="text" name="adName" id="adName" required><br><br>

  <label for="quantity">จำนวน:</label>
  <input type="number" name="quantity" id="quantity" required><br><br>

  <label for="agencyID">เอเจนซี:</label>
  <select name="agencyID" id="agencyID">
    <?php
    $stmt = $conn->query("SELECT * FROM Agencies");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
      echo "<option value='{$row['AgencyID']}'>{$row['AgencyName']}</option>";
    }
    ?>
  </select><br><br>

  <input type="submit" value="ซื้อป้ายโฆษณา">
</form>

</body>
</html>